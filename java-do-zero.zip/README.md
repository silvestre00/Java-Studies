# Aprendizados em Java do Zero 👨‍💻☕

Este repositório contém minha jornada de estudos em Java, organizada por blocos temáticos:

## 🔰 Blocos de Estudo

- **Bloco 1 – Introdução ao Java**  
  Estrutura básica de um programa Java, instalação e `System.out.println`.

- **Bloco 2 – Variáveis, Tipos de Dados e Operadores**  
  Declaração de variáveis, tipos primitivos, operadores aritméticos e lógicos.

- **Bloco 3 – Estruturas Condicionais**  
  Uso de `if`, `else`, `switch-case`, operadores de comparação.

- **Bloco 4 – Laços de Repetição**  
  Estruturas `for`, `while`, `do-while`, uso de `break` e `continue`.

## 🧠 Objetivo

Dominar os fundamentos da linguagem Java do zero até o nível júnior, construindo uma base sólida para projetos e futuras oportunidades no mercado de tecnologia.

## 📁 Organização

Cada bloco possui arquivos `.java` com exercícios e desafios práticos.

## 📌 Progresso

- [x] Bloco 1
- [x] Bloco 2
- [x] Bloco 3
- [x] Bloco 4
- [ ] Bloco 5 – Entrada de Dados e Mini Projeto

---
🚀 *Repositório mantido por [Seu Nome](https://github.com/seu-usuario)*
